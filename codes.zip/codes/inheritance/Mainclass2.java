package inheritance;


class Superclass1 extends Object
{
	public Superclass1()
	{
	   super();
       System.out.println("this is superclass const()");
	}
}


class Superclass2 extends Object
{
	public Superclass2()
	{
	   super();
       System.out.println("this is superclass const()");
	}
}
class Subclass extends Superclass1
{
	public Subclass()
	{
	   super();
       System.out.println("this is subclass const()");
	}
}

public class Mainclass2 
{
	public static void main(String[] args) 
	{
       Subclass ref1 = new Subclass();
	}
}
