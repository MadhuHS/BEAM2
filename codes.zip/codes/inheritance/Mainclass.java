package inheritance;

class SimpleCalculator 
{
	public void add(int a1, int b1) 
	{
		System.out.println(a1 + b1);
	}

	public void sub(int a1, int b1) 
	{
		System.out.println(a1 - b1);
	}

	public void div(int a1, int b1) 
	{
		System.out.println(a1 / b1);
	}

	public void mul(int a1, int b1) 
	{
		System.out.println(a1 * b1);
	}

	public void mod(int a1, int b1)
	{
		System.out.println(a1 % b1);
	}
}

class SciCalculator extends SimpleCalculator
{
	public void cubeRoot(int a1)
	{
	  System.out.println(Math.cbrt(a1));	
	}
	
	public void tan(int a1)
	{
	  System.out.println(Math.tan(a1));	
	}
}

public class Mainclass {
	public static void main(String[] args) {
		SimpleCalculator s1 = new SimpleCalculator();
		s1.add(10, 20);
		
		SciCalculator sc1 = new SciCalculator();
		sc1.cubeRoot(4);
		sc1.add(2,3);
		sc1.tan(12);
	}
}



