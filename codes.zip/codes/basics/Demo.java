package basics;

public class Demo 
{
   public static void main(String[] args) 
   {
	 System.out.println("hello world");// ""->string value
	 
	 int v1 = 10;//declaration and intialization
	 int v2 = 20;
	 int res;
	 
	 res = v1 + v2;//utilization
	 System.out.println(res);
	 
   }
}

