package flowcontrol;

public class Program4 
{
  public static void main(String[] args) 
  {
     System.out.println("for loop");
	 for(int count=1; count <= 3; count+=2)
	 {
	  System.out.println("hello world");	
	 }
	 
	 System.out.println("while loop");
	 
	 int count1 = 1;
	 while(count1 <= 3)
	 {
       System.out.println("hello world");
       count1++;
	 }
	 
	 System.out.println("do while loop");
	 int count2 = 5;
	 
	 do
	 {
		 System.out.println("hello world");
	     count2 = count2+2; 
	 
	 }while(count2 <= 3);
  }
}



