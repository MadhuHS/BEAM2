package flowcontrol;

public class Program3 
{
 public static void main(String[] args)
 {
    char optn = 'A';
    
    switch(optn) 
    {
	case 'A': System.out.println("optn A selected");
		      break;
	case 'B': System.out.println("optn B selected");
              break;
	case 'C': System.out.println("optn C selected");
              break;
	case 'D': System.out.println("optn D selected");
              break;
    default : System.out.println("Invalid Choice");
	}
    
 }
}






