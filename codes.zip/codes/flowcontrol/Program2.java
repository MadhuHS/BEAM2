package flowcontrol;

public class Program2 {

	public static void main(String[] args) 
	{
        int x1 = 506;//between 1 to 100
        
        if(x1 >= 1 && x1 <= 100)
        {
        	  System.out.println("x1 is between 1 to 100");
        }
        else
        {
      	  System.out.println("x1 is out of range");
        }
        
	}

}
