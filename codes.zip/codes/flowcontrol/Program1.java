package flowcontrol;

public class Program1
{
  public static void main(String[] args) 
  {
     int v1 = 10;
     
     System.out.println(v1);
     if(v1 > 10)// > < == != >= <= compare ---> boolean-true,false
     {
       System.out.println("v1 is larger than 10");
     }
     else if(v1 == 10)
     {
    	   System.out.println("v1 is equal to 10");
     }
     else
     {
      System.out.println("v1 is smaller than 10");
     }
  }
}




